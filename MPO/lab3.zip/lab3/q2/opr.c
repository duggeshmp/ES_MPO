#include "header.h"

void insert_array_element(int *arr,int arr_len)
{
	int i;

	for(i = 0;i < arr_len;i++)
		*(arr+i) = ((i+1)*737*27)%159;
}


void thread1(void *ptr)
{
	int i;
	Arra *arr = (Arra *)ptr;
	

	for(i = 0;i < ARRAY1_SIZE;i++)
	 printf("\nThread Id:- %u sum %d",gettid(),arr->arr1[i]+arr->arr2[i]);
}
void thread2(void *ptr)
{
	int i;
	Arra *arr = (Arra *)ptr;

	for(i = 0;i < ARRAY1_SIZE;i++)
	 printf("\nThread Id:- %u sum %d",gettid(),arr->arr1[i]+arr->arr2[i]);
}
void thread3(void *ptr)
{
	int i;
	Arra *arr = (Arra *)ptr;

	for(i = 0;i < ARRAY1_SIZE;i++)
	 printf("\nThread Id:- %u sum %d",gettid(),arr->arr1[i]+arr->arr2[i]);
}
void thread4(void *ptr)
{
	int i;
	Arra *arr = (Arra *)ptr;
	for(i = 0;i < ARRAY1_SIZE;i++)
	 printf("\nThread Id:- %u sum %d",gettid(),arr->arr1[i]+arr->arr2[i]);
}

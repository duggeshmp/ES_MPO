#include "header.h"

int main()
{
	int arr[ARRAY_SIZE];
	pthread_t thrd1,thrd2;

	insert_array_element(arr);

	while(0 != pthread_create(&thrd1,NULL,(void *)&thread1,arr));
	while(0 != pthread_create(&thrd2,NULL,(void *)&thread2,arr));
	
	pthread_join(thrd1,NULL);
	pthread_join(thrd2,NULL);
	
	return 0;
}
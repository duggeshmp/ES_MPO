#include "header.h"

int main()
{
	int arr[ARRAY_SIZE];
	pthread_t thrd1,thrd2,thrd3,thrd4;

	insert_array_element(arr);

	while(0 != pthread_create(&thrd1,NULL,(void *)&thread1,arr));
	while(0 != pthread_create(&thrd2,NULL,(void *)&thread2,arr));
	while(0 != pthread_create(&thrd3,NULL,(void *)&thread3,arr));
	while(0 != pthread_create(&thrd4,NULL,(void *)&thread4,arr));
	
	pthread_join(thrd1,NULL);
	pthread_join(thrd2,NULL);
	pthread_join(thrd3,NULL);
	pthread_join(thrd4,NULL);
	return 0;
}
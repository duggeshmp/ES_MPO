#include "header.h"


int main()
{
	Arra Arr;
	pthread_t thrd1,thrd2;

	insert_array_element(Arr.arr1,ARRAY1_SIZE);
	insert_array_element(Arr.arr2,ARRAY2_SIZE);

	while(0 != pthread_create(&thrd1,NULL,(void *)&thread1,&Arr));
	while(0 != pthread_create(&thrd2,NULL,(void *)&thread2,&Arr));

	
	pthread_join(thrd1,NULL);
	pthread_join(thrd2,NULL);

	return 0;
}
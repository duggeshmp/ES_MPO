#include<stdio.h>

int main()
{

	int num1,num2;

	printf("enter two numbers\n");
	scanf("%d %d",&num1,&num2);

	printf("\nNumbers are:- ");

	for(int i = 0;i < num2;i++)
		if(i%num1 == 0) printf("%d ",i);
	return 0;
}
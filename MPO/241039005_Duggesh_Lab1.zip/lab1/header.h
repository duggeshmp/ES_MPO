#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 1000

void Insert_martix1(int **mat,int size);

void Insert_martix2(int **mat,int size);

void Print_martix(int mat[][SIZE],int size);

void Add_mul_2_matrix(int add[][SIZE],int multiply[][SIZE],int mat1[][SIZE],int mat2[][SIZE]);

void Multiply_2_matrix(int multiply[][SIZE],int mat1[][SIZE],int mat2[][SIZE]);